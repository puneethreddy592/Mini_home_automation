const express = require('express');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const port = 8080;

app.use(express.static(path.join(__dirname, 'public')));

const wss = new WebSocket.Server({ noServer: true, path: '/ws' });

const espClients = [];
const webClients = [];

wss.on('connection', (ws, req) => {
  if (req.url === '/ws') {
    //
    console.log('ESP8266 connected');
    espClients.push(ws);

    
    ws.on('message', (message) => {
      console.log(`Received from ESP8266: ${message}`);
      
        broadcastToClients(message, [...espClients, ...webClients], ws);
    });
    ws.on('close', () => {
      const index = espClients.indexOf(ws);
      if (index > -1) {
        espClients.splice(index, 1);
      }
      console.log('ESP8266 disconnected');
    });

  } else {
    
    console.log('Web client connected');
    webClients.push(ws);

    ws.on('message', (message) => {
      console.log(`Received from Web client: ${message}`);
      
      broadcastToClients(message, [...espClients, ...webClients], ws);
    });

    ws.on('close', () => {
      const index = webClients.indexOf(ws);
      if (index > -1) {
        webClients.splice(index, 1);
      }
      console.log('Web client disconnected');
    });
  }
});


const server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

server.on('upgrade', (request, socket, head) => {
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

function broadcastToClients(message, clients, sender = null) {
  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// Serve the main web page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
